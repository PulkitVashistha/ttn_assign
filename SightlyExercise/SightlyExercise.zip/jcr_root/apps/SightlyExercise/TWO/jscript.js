use(function () {
    
    var value = java.util.Date().toString();
    
    return {
        datetime: value
    };
});
